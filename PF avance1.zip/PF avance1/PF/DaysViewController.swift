//
//  DaysViewController.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio, Salas Pineda Ricardo. All rights reserved.
//

import UIKit

class DaysViewController: UIViewController {

    @IBOutlet weak var DAYIMAGE: UIImageView!
    @IBOutlet weak var DAYNAME: UILabel!
    
    var Days: DaysData!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DAYNAME.text = Days.Dayname
        DAYIMAGE.image = Days.Dayimage

    }

}
