//
//  LetterViewController.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio,  Salas Pineda Ricardo. All rights reserved.
//

import UIKit

class LetterViewController: UIViewController {

    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var letter: UILabel!
    
    var LETTER: LetterData!
    override func viewDidLoad() {
        super.viewDidLoad()

        letter.text = LETTER.nombre
        image.image = LETTER.imagen
        
    }
}
