//
//  NumberViewController.swift
//  PF
//
//  Copyright © 2018 Martínez Mendoza Aarón, Lopez Ceciliano Brett Antonio, Salas Pineda Ricardo. All rights reserved.
//

import UIKit

class NumberViewController: UIViewController {

    @IBOutlet weak var number: UILabel!
    @IBOutlet weak var NUMIMAGE: UIImageView!
    var NUMBER: NumberData!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        number.text = NUMBER.number
        NUMIMAGE.image = NUMBER.numimage
    }

}
